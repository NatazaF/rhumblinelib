Rhumbline
=================================

Wrapper for Rhumbline functions of geographiclib
